<?php 
include('root/config.php');
 ?>
 <!DOCTYPE html>
<html lang="en">
	<head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
        <meta charset="utf-8">
        <title>Knoisa | Search</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/facebook.css" rel="stylesheet">
    </head>
    <body>
    	
<?php include('header.php'); ?>	


				<div class="padding">
					<div class="full col-sm-12">
                        <div class="row">
                            <div class="col-sm-4"></div>
                         <!-- main col left --> 
                            <div class="col-sm-4">
                                <div class="panel panel-default">
                                    <div class="emp-profile">
                                        <div class="form-group row">
                                            <label for="search" class="col-sm-2 col-form-label">Search</label>
                                            <div class="col-sm-10">
                                            <input type="text" class="form-control" id="search" name="search" placeholder="Search by UserName" >
                                            </div>
                                        </div>
                                    </div>
                                    <div id="result" class="panel-body">
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- main col left --> 
                            <div class="col-sm-4"></div>
                        </div><!-- row end -->

<?php include('footer.php') ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
      // Send Search Text to the server
      $("#search").keyup(function () {
        let searchText = $(this).val();
        if (searchText != "") {
          $.ajax({
            url: "ajex_search.php",
            method: "post",
            data: {
              query: searchText,
            },
            success: function (response) {
              $("#result").html(response);
            },
          });
        } else {
          $("#result").html("");
        }
      });
      // Set searched text in input field on click of search button
      $(document).on("click", "a", function () {
        $("#search").val($(this).text());
        $("#result").html("");
      });
    });
</script>
