<?php 

include 'root/config.php';
 if (isset($_POST['query'])) {
     $query = "SELECT * FROM tbl_user WHERE username LIKE '{$_POST['query']}%' LIMIT 100";
      $result = $ai_db->aiGetQueryObj($query);

    if ($result) {
      foreach ($result as $row) {
?>
       <a href="search_profile.php?id=<?php echo $row->id; ?>">
            <img src="profile_images/<?php echo $row->profile_img; ?>" height="28px" width="28px" style="border-radius: 50px;"> <?php echo $row->username; ?> 
        </a>
<?php
      }
    } else {
      echo '<p class="list-group-item border-1 alert alert-danger mt-3 text-center">UserName Not Found</p>';
    }
  }
?>
