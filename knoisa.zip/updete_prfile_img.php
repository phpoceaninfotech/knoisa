<?php
include('root/config.php');

$pageUrl = "profile.php";
$imageUrl = "profile_images/";

//$id = $_SESSION['aid'];
if (isset($_POST['btn_submit'])) {

$image_path = $ai_core->aiUpload($_FILES['cover_image'], $imageUrl, 'profile_img', $_POST['old_file_name']);

	 $editqry = "UPDATE tbl_user SET 
				   profile_img='".$image_path."' WHERE id='".$_SESSION['aid']."' ";
            $ai_db->aiQuery($editqry);

        $ai_core->aiGoPage($pageUrl);
}
?>
 <!DOCTYPE html>
<html lang="en">
	<head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
        <meta charset="utf-8">
        <title>Knoisa | Edit Profile Photo</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/facebook.css" rel="stylesheet">
    </head>
    
    <body>
<?php include('header.php'); ?>

	<div class="padding">
		<div class="full col-sm-12">
			<div class="container emp-profile">	
				<div class="row">
					<div class="col-md-12">
					    <div class="">
					   		<form name="frm" id="frm" data-parsley-validate method="POST" action="" enctype="multipart/form-data">
								<div class="row">
									<div class="col-md-4">
										<div class="profile-img">
						                    <img src="profile_images/user.jpg" id="preview" />
						                    <div class="file btn btn-lg btn-primary">
						                    	Edit Profile Picture
						                      	<input type="file" name="cover_image" id="cover_image" accept="image/*" onchange="previewImage();"/>
						                      	<input type="hidden" name="old_file_name" id="old_file_name" value="" />
						                    </div> 
						                </div>
									</div>
									<div class="col-md-8">
										<div class="form-group row">
											<label class="col-sm-2 col-form-label"></label>
											<div class="col-sm-10" style="margin-left:25px;">
												<button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-primary"><i class="icon-plus"></i> Submit</button>
												<a href="profile.php" class="btn btn-warning"><i class="icon-minus"></i> Cancel</a>
							            	</div>
							          	</div>
									</div>
								</div>
					        </form>   
					   	</div>
		    		</div>
		        </div> 	
			</div>
				
<?php include('footer.php') ?>
<script>
    function previewImage() {
        var file = document.getElementById("cover_image").files
        if (file.length > 0) {
            var fileReader = new FileReader()
 
            fileReader.onload = function (event) {
                document.getElementById("preview").setAttribute("src", event.target.result)
            }
 
            fileReader.readAsDataURL(file[0])
        }
    }
</script>