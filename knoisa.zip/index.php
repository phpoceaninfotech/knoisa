<?php 
include('root/config.php');
 ?>
 <!DOCTYPE html>
<html lang="en">
	<head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
        <meta charset="utf-8">
        <title>Knoisa | Home</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/facebook.css" rel="stylesheet">
    </head>
    <body>
    	
<?php include('header.php'); ?>	

				<div class="padding">
					<div class="full col-sm-12">
<?php 
$index_qry = "SELECT * FROM tbl_user INNER JOIN tbl_upload_image ON tbl_user.id = tbl_upload_image.user_id Where tbl_user.status='active' AND tbl_upload_image.status='active' ";  
$incex_result = $ai_db->aiGetQueryObj($index_qry);
	if (COUNT($incex_result) > 0) {
		foreach ($incex_result as $index_row) {
?>	
			  
						<!-- content -->                      
						<div class="row">
						 	<div class="col-sm-4"></div>
						 <!-- main col left --> 
						 	<div class="col-sm-4">
							  	<div class="panel panel-default">
									<div class="panel-body">
										<a href="">
											<img src="profile_images/<?php echo $index_row->profile_img; ?>" height="28px" width="28px" style="border-radius: 50px;">
											<?php echo $index_row->username; ?> 
										</a>
									  	<p style=" font-size: 14px;font-family: 'arial';"><?php echo $index_row->description; ?></p>
									</div>
									<div class="panel-thumbnail">
										<a class="lightbox" href="upload_image/<?php echo $index_row->image; ?>">
											<img src="upload_image/<?php echo $index_row->image; ?>" width="500px" height="" class="img-responsive">
										</a>
									</div>
							  	</div>
					   		</div>
					   		<!-- main col left --> 
					   		<div class="col-sm-4"></div>
						</div><!-- row end -->
<?php } } ?>
					  
<?php include('footer.php') ?>

<script>
    baguetteBox.run('.lightbox');
</script>