<?php
include('root/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/facebook.css" rel="stylesheet">
	<title>Knoisa | Sing-up</title>
	<style type="text/css">
/*		body{margin: 0;padding: 0;background-color:#000;no-repeat;}*/
	</style>
</head>
<body>
	<div class="loginBox"> <img class="user" src="assets/img/logo2.png" height="auto" width="200px">
        <h3></h3>
        <form action="" method="post">
            <div class="inputBox"> 
                <input id="email" type="email" name="email" placeholder="Enter Your Email">
                <input id="name" type="text" name="name" placeholder="Enter Your Name"> 
                <input id="uname" type="text" name="username" placeholder="Enter Your Username"> 
                <input id="pass" type="password" name="password" placeholder="Enter Your Password">
            </div> <input type="submit" name="btn_submit" id="btn_submit" value="Sign-Up">
        </form>
    </div>
</body>
</html>
<?php 

$pageUrl = "login.php";

if(isset($_POST['btn_submit'])){

$email = $_POST['email'];
$name = $_POST['name'];
$username = $_POST['username'];
$password = md5($_POST['password']);
$status = $_POST['status'];
$profile_img = $_POST['profile_img'];

$add_qry = "INSERT INTO tbl_user SET 
           email='".$email."',     
           name='".$name."',
           username='".$username."',    
           password='".$password."',
           profile_img='user.jpg',
           status='active'";    
              $ai_db->aiQuery($add_qry);
        $ai_core->aiGoPage($pageUrl);
        
}

?>