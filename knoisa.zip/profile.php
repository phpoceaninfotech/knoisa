<?php 
include('root/config.php');

$imageUrl = "../profile_images/";
?>
 <!DOCTYPE html>
<html lang="en">
	<head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
        <meta charset="utf-8">
        <title>Knoisa | Profile</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/facebook.css" rel="stylesheet">
    </head>
    
    <body>
<?php include('header.php'); ?>

				<div class="padding">
					<div class="full col-sm-12">

					<?php if ($_SESSION['aid'] != "") { ?>
<?php 
$profile_qry = "SELECT * FROM tbl_user WHERE status='active' AND id='".$_SESSION['aid']."'";
$profile_result = $ai_db->aiGetQueryObj($profile_qry);
	if (COUNT($profile_result) > 0) {
		foreach ($profile_result as $profile_row) {
?>
						<!-- profile image section  -->
						<div class="  emp-profile">
						    <form method="post">
						        <div class="row">
						            <div class="col-md-4">
						                <div class="profile-img">
						                    <img src="profile_images/<?php echo $profile_row->profile_img ; ?>" alt=""/>
						                    <div class="file btn btn-lg btn-primary">
						                      <a href="updete_prfile_img.php?edit&id=<?php echo $profile_row->id ?>" type="submit" style="color: #fff;">Edit Profile img</a>
						                    </div> 
						                </div>
						            </div>
						            <div class="col-md-6">
						                <div class="profile-head">
						                    <h4>
						                        <?php echo $profile_row->username; ?>
						                    </h4>
						                    <h6>
						                        <?php echo $profile_row->name; ?>
						                    </h6>   
						                </div>
						            </div>
						            <div class="col-md-2">
						                <a href="edit_profile.php?edit&id=<?php echo $profile_row->id ?>" type="submit" class="profile-edit-btn"><i class="glyphicon glyphicon-edit"></i> Edit Profile</a>
						            </div>
						        </div>
<?php } }  ?>
		

						        <!-- post image section -->
						        <div class="row image">
						            <div class="col-md-4"></div>
			            
						            <div class="col-md-8">
						                <div class="tz-gallery">
						                	<h4 style="border-bottom: 1px solid #000;"><i class="glyphicon glyphicon-th"></i> Post</h4>
						                    <div class="row">
<?php 
$upload_img_qry = "SELECT * FROM tbl_upload_image WHERE status='active' AND user_id='".$_SESSION['aid']."' ";
$upload_img_result = $ai_db->aiGetQueryObj($upload_img_qry);
if(COUNT($upload_img_result) > 0 ){
	foreach($upload_img_result as $upload_img_row) {
?>	
						                        <div class=" col-md-4">
						                            <a class="lightbox" href="upload_image/<?php echo $upload_img_row->image; ?>">
						                                <img class="profile_images"src="upload_image/<?php echo $upload_img_row->image; ?>" width="500px" height="200px" alt="upload_img"/>
						                            </a>
						                        </div>
<?php } } ?>
						                    </div>
						                </div>
						        	</div>

						    	</div>



							</form>           
						</div>
					
 
					  	<?php } else {  ?>
					  		<div class="tag_line">
					  			<script>
							    alert('Please Login And Crate Profile...');
							    window.location='login.php';
							    </script>
					  		</div>
						<?php } ?>
<?php include('footer.php') ?>

<script>
    baguetteBox.run('.tz-gallery');
</script>
<!-- Click Here and  Please Login And Crate Profile  -->