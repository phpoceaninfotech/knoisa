<?php 
include('root/config.php');

$imageUrl = "../profile_images/";

$qry = "SELECT * FROM tbl_user WHERE id=".$_SESSION['aid'];
    $row = $ai_db->aiGetQueryObj($qry);
    if (isset($_POST['btn_submit'])) {
        $old_pass = $_POST['old_pass'];
        $n_passs = md5($_POST['n_passs']);
        if ($old_pass != '') {
            $qry = "UPDATE tbl_user SET password='".$n_passs."'";
        }
        $qry .= " WHERE id='".$_SESSION['aid']."'";
        $ai_db->aiQuery($qry);
        ?>
        <script>
            alert('Your Profile Successfully Updated Try Using New Credential!');
              window.location.href = "logout.php";
        </script>
        <?php
      
    }
 ?>
<!DOCTYPE html>
<html lang="en">
	<head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
        <meta charset="utf-8">
        <title>Knoisa | Edit Profile</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/facebook.css" rel="stylesheet">
    </head>
    
    <body>
<?php include('header.php'); ?>

<div class="padding">
	<div class="full col-sm-12">

	<!-- profile image section  -->
		<div class="container emp-profile">	
			<div class="row">
				<div class="col-md-4">
				    <div class="profile-img">
				        <img src="profile_images/<?php echo $row[0]->profile_img ; ?>" alt=""/>
				    </div>
				</div>
				<div class="col-md-8">
				    <div class="profile-head2">
				   		<form name="frm" id="frm" data-parsley-validate method="POST" action="" enctype="multipart/form-data">
							<input type="hidden" name="mode" id="mode" value="<?php echo $_REQUEST['mode']; ?>" />
							<input type="hidden" name="id" id="id" value="<?php echo $_REQUEST['id']; ?>" />
							
							<div class="form-group row">
								<label for="input-21" class="col-sm-2 col-form-label">Username</label>
								<div class="col-sm-10">
								<input type="text" class="form-control" id="uname" name="uname" value="<?php echo $row[0]->username; ?>">
								</div>
							</div>
							
							<div class="form-group row">
								<label for="input-21" class="col-sm-2 col-form-label">Email</label>
								<div class="col-sm-10">
								<input type="text" class="form-control" id="email" name="email" value="<?php echo $row[0]->email; ?>">
								</div>
							</div>
							
							<hr>
							
							<div class="form-group row">
								<label for="input-21" class="col-sm-2 col-form-label">Old Password</label>
								<div class="col-sm-10">
								<input type="password" class="form-control" id="old_pass" name="old_pass" required />
								</div>
							</div>
							
							<div class="form-group row">
								<label for="input-21" class="col-sm-2 col-form-label">New Password</label>
								<div class="col-sm-10">
								<input type="password" class="form-control" id="n_passs" name="n_passs">
								</div>
							</div>
							
							<div class="form-group row">
								<label for="input-21" class="col-sm-2 col-form-label">Confirm Password</label>
								<div class="col-sm-10">
								<input type="password" class="form-control" id="cn_pass" name="cn_pass">
								</div>
							</div>
							
							<div class="form-group row">
								<label class="col-sm-2 col-form-label"></label>
								<div class="col-sm-10 text-center">
									<button type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-primary"><i class="icon-plus"></i> Submit</button>
									<a href="profile.php" class="btn btn-warning"><i class="icon-minus"></i> Cancel</a>
				            	</div>
				          </div>

				          </form>   
				        </div>
	    			</div>
	         	</div> 	
			</div>
 
					  
<?php include('footer.php') ?>

<script>
    $(document).ready(function () {
        $("#old_pass").focusout(function () {
            var old_pass = $("#old_pass").val();
            $.ajax({
                type: "POST",
                url: "ajax_login.php",
                data: {action: 'check-password', old_pass: old_pass}
            }).done(function (msg) {
                if (msg == 'fail')
                {
                    alert('Invalid Old Password Enter Valid Password!');
                    document.getElementById('old_pass').value = "";
					ocument.getElementById('old_pass').focus();

                } else {
                    var v1 = document.getElementById("n_passs");
                    v1.setAttribute("required", "required");
                    var v2 = document.getElementById("cn_pass");
                    v2.setAttribute("required", "required");
                }
            });
        });
        $("#cn_pass").focusout(function () {
            var n_pass = $("#n_passs").val();
            var cn_pass = $("#cn_pass").val();
            if (n_pass != cn_pass)
            {
                alert('New Password And Confirm Password Does Not Match Please Enter Correct!');
                document.getElementById('cn_pass').value = "";
            }
        });
    });
</script>