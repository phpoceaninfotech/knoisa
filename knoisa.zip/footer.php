					<hr>
					  
					  <h4 class="text-center">
					  <a href="#">Copyright &copy; 2023 <a href="#">Knoisa</a>. All Right Reserved <br>Design & Developed By <a href="http://oceaninfotech.co.in/">Ocean Infotech </a></div></a>
					  </h4>
						
					  <hr>
						
					  
					</div><!-- /col-9 -->
				</div><!-- /padding -->
			</div>
			<!-- /main -->
		  
		</div>
	</div>
</div>


<!--post modal
<div id="postModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
	  <div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			Update Status
	  </div>
	  <div class="modal-body">
		  <form class="form center-block">
			<div class="form-group">
			  <textarea class="form-control input-lg" autofocus="" placeholder="What do you want to share?"></textarea>
			</div>
		  </form>
	  </div>
	  <div class="modal-footer">
		  <div>
		  <button class="btn btn-primary btn-sm" data-dismiss="modal" aria-hidden="true">Post</button>
			<ul class="pull-left list-inline"><li><a href=""><i class="glyphicon glyphicon-upload"></i></a></li><li><a href=""><i class="glyphicon glyphicon-camera"></i></a></li><li><a href=""><i class="glyphicon glyphicon-map-marker"></i></a></li></ul>
		  </div>	
	  </div>
  </div>
  </div>
</div>-->

<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.js"></script>
<!-- profile image show link -->
<link rel="stylesheet" href="assets/css/baguetteBox.min.css">
<!-- profile image scroll image and view all image link  -->
<script src="assets/js/baguetteBox.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$('[data-toggle=offcanvas]').click(function() {
		$(this).toggleClass('visible-xs text-center');
		$(this).find('i').toggleClass('glyphicon-chevron-right glyphicon-chevron-left');
		$('.row-offcanvas').toggleClass('active');
		$('#lg-menu').toggleClass('hidden-xs').toggleClass('visible-xs');
		$('#xs-menu').toggleClass('visible-xs').toggleClass('hidden-xs');
		$('#btnShow').toggle();
	});
});
</script>
</body>
</html>