<?php
include('root/config.php');
if ($_SESSION['aid'] != "") {
    ?>
    <script>
    alert('You Have Alrady Log-In..........');
    window.location='index.php';
    </script>
    <?php
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/facebook.css" rel="stylesheet">
	<title>Knoisa | Login</title>
	<style type="text/css">
/*		body{margin: 0;padding: 0;background-color:#000;no-repeat;}*/
	</style>
</head>
<body>
	<div class="loginBox"> <img class="user" src="assets/img/logo2.png" height="auto" width="200px">
        <h3></h3>
        <form action="" method="post" >
            <div class="inputBox"> 
            <input  type="text" name="inputEmail" id="inputEmail" placeholder="Enter Your Email">
            <input  type="password" name="inputPass" id="inputPass" placeholder="Enter Your Password"> 
            </div>
            <input type="submit" id="login-btn" value="Login">
        </form>
        <div class="text-center">
            <p style="color: #999999;">Don't Have an Account?</p>
        </div> 
        <a href="signup.php">Sign-Up<br> </a>
    </div>
</body>
</html>
<!-- jquery File  -->
   <script src="assets/js/jquery.min.js"></script>
<script>
        $(document).ready(function () {
            $("#login-btn").click(function () {
                var inputEmail = $("#inputEmail").val();
                var loginPassword = $("#inputPass").val();
                if (inputEmail == '')
                {
                    alert("Please Enter Username!");
                    $("#inputUsername").focus();
                    return false;
                }
                if (loginPassword == '')
                {
                    alert("Please Enter Password!");
                    $("#inputPass").focus();
                    return false;
                }
                $.ajax({
                    type: "POST",
                    url: "ajax_login.php",
                    data: {
                        action: "login",
                        inputEmail: inputEmail,
                        loginPassword: loginPassword
                    },
                    success: function (data)
                    {
                        if (data == "success")
                        {
                            document.location.href = 'index.php';
                        }
                        else if (data == "not active")
                        {
                            alert('Your account is not active. Please contact administrator for that.');
                        }
                        else if (data == "not found1")
                        {
                            alert('not found');
                        }
                        else
                        {
                            alert('Wrong Username OR Password!');
                        }
                    },
                    error: function ()
                    {
                        alert('Error while contacting server, please try again');
                    }
                });
            });
        });
        </script>