        // $(document).ready(function () {
        //     $("#search").keyup(function () {
        //         var query = $(this).val();
        //         if (query != "") {
        //             $.ajax({
        //                 url: 'ajex_search.php',
        //                 method: 'POST',
        //                 data: {
        //                     query: query
        //                 },
        //                 success: function (data) {
        //                     $('#result').html(data);
        //                     $('#result').css('display', 'block');

        //                     $("#search").focusout(function () {
        //                         $('#result').css('display', 'none');
        //                     });
        //                     $("#search").focusin(function () {
        //                         $('#result').css('display', 'block');
        //                     });
        //                 }
        //             });
        //         } else {
        //             $('#result').css('display', 'none');
        //         }
        //     });
        // });


          // if (isset($_POST['query'])) {
  //     $query = "SELECT * FROM tbl_user WHERE username LIKE '{$_POST['query']}%' LIMIT 100";
  //     $result = $ai_db->aiGetQueryObj($query);
  //   if (COUNT($result) > 0) {
  //       foreach ($result as $row) {
        ?>
        <!-- <a href="profile.php"> <?php echo $row->username; ?> </a> -->
       <?php
       
  //     }
  //   } else {
  //     echo "
  //     <div class='alert alert-danger mt-3 text-center' role='alert'>
  //         username not found
  //     </div>
  //     ";
  //   }
  // }